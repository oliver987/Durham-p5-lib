
let simulation;
function setup() {
    simulation = new ParticleSimulation();
    simulation.setup()
}
function draw() {
    simulation.draw();
}